<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="/projetoa/">
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" />
    <title>footer</title>
</head>
<body>
    <footer>
    <figure>
        <img src="/projetoa/app/assets/img/alien-footer.png" />
      </figure>
        <div class="padding"></div>
        <div class="rodape">
            <p>Feito por:</p>
            <p>Amanda Santana Araújo</p>
            <p>Turma A</p>
            <p>3º INFO</p>
        </div>
        <div class="padding"></div>
        <div class="rodape">
            <p>IFSP - GRU</p>
            <p>Profº Anselmo</p>
            <p>Laboratório de Desenvolvimento para Internet</p>
        </div>
    </footer>
</body>