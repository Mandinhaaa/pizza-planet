<?php
    include_once "../../factory/conexao.php";
    if(isset($_GET["cxpesquisacomercio"])) {
        $nome = $_GET["cxpesquisacomercio"];
        $consultar = "SELECT * FROM tbcomercio WHERE nome = '$nome'";
        $executar = mysqli_query($conn, $consultar);
        $linha = mysqli_fetch_array($executar);

        
    }
        
?>