<?php
    // CONSULTA USUÁRIO NO BANCO USANDO URL
    include_once "../../factory/conexao.php";
    if(isset($_GET["cxpesquisaamigos"])) {
        $amigo = $_GET["cxpesquisaamigos"];
        $consultar = "SELECT * FROM tbamigos WHERE amigo = '$amigo'";
        $executar = mysqli_query($conn, $consultar);
        $linha = mysqli_fetch_array($executar);

        
    }
        
?>