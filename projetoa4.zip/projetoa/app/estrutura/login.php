<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" /> 
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />    <title>Login</title>
</head>
<body>

  <header class="banner">
      <div class="menu-img">
        <img src="../assets/img/pizza1.png" alt="" />
      </div>

        <nav>
          <ul>
            <li><a class="item-menu" href="../../index.php">Home</a></li>
            <li><a class="item-menu" href="../estrutura/menu.php">Menu</a></li>
            <li><a class="item-menu" href="../estrutura/login.php">Login</a></li>
          </ul>
        </nav>
    </header>

    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
          <figure>
              <img src="/projetoa/app/assets/img/alien.png" alt=""/>
            </figure>
            <form action="/projetoa/app/estrutura/open.php" method="POST">

            <input
                class="input"
                type="e-mail"
                name="cxemail"
                placeholder="Digite seu e-mail"
                required
                />
              <input
                class="input"
                type="password"
                name="cxsenha"
                placeholder="Digite uma senha"
                required
              />
              <input class="button" type="submit" value="Acessar" />

            </form>
            Não é cadastrado?
            <a href="/projetoa/acoes/cadastro/cadastro-login.php">Cadastre-se!</a>
          </div>
        </div>
      </div>
    </section>


    <?php include '../estrutura/footer.php'; ?>

    <!-- <section id="cxprincipal">
        <figure id="cxcadeado">
            <img src="img/foto.png" alt="">
        </figure>

        <header id="cxlogin">
            <h1>Login</h1> <br>
            Email: <br>
            <input type="email" name="cxemail" class="cxemail"><br>
            Senha: <br>
            <input type="password" name="cxsenha" class="cxsenha"><br>
            <br/>
            <input type="submit" value="acessar">
        </header>
    </section> -->
    
</body>
</html>