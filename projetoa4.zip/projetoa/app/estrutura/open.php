<?php
    SESSION_START();

    include_once "../../factory/conexao.php";
    $email = $_POST["cxemail"];
    $senha = $_POST["cxsenha"];
    $sql = "select*from tblogin WHERE email = '$email' AND senha = '$senha' ";
    $result = mysqli_query ($conn,$sql);
    if(mysqli_num_rows($result) > 0){
        $_SESSION["email"] = $email;
        $_SESSION["senha"] = $senha;
        header ('location:/projetoa/app/estrutura/menu.php');
    } else {
        echo "E-mail e senha errado!";
        unset( $_SESSION["email"]);
        unset( $_SESSION["email"]);
    }


?>