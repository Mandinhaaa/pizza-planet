<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    <title>Consulta comércio</title>
</head>
<body>
</head>
  <body>
    <header class="banner">
      <div class="menu-img">
        <img src="../../app/assets/img/pizza1.png" alt="" />
      </div>

      <nav>
        <ul>
          <li><a class="item-menu" href="../../index.php">Home</a></li>
          <li><a class="item-menu" href="../../app/estrutura/menu.php">Menu</a></li>
          <li><a class="item-menu" href="../../app/estrutura/login.php">Login</a></li>
        </ul>
      </nav>
    </header>

    <?php include 'acoes/busca/busca-comercio.php'?>


    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
                    <form action="acoes/consulta/consulta-comercio.php">
                        <input class="input" type="text" name="cxpesquisacomercio" placeholder="Digite o nome cadastrado">
                        <input class="button" type="submit" value="Buscar">
                    </form>

              <input
                class="input"
                type="text"
                name="cxnome"
                value="<?= isset($linha['nome']) ? $linha['nome'] : ''; ?>"
              />
              <input
                class="input"
                type="text"
                name="cxcomercio"
                value="<?= isset($linha['comercio']) ? $linha['comercio'] : ''; ?>"
              />
              <input
                class="input"
                type="text"
                name="cxtelefone"
                value="<?= isset($linha['telefone']) ? $linha['telefone'] : ''; ?>"
              />
              <input
                class="input"
                type="text"
                name="cxwhats"
                value="<?= isset($linha['whats']) ? $linha['whats'] : ''; ?>"
              />
          </div>
        </div>
      </div>
    </section>

    <?php include '../estrutura/footer.php'; ?>


</body>
</html>