<?php
    include_once "../../factory/conexao.php";

    // $produto = $_POST["cxproduto"];
    // $marca = $_POST["cxmarca"];
    
    $id = $_POST["cxcodigo"];
    $amigo = $_POST["cxamigo"];
    $email = $_POST["cxemail"];
    $telefone = $_POST["cxtelefone"];
    $whats = $_POST["cxwhats"];
    $nascimento = $_POST["cxdatanasc"];

    $alterar = "
    UPDATE tbamigos SET 
    amigo = '$amigo',
    email = '$email',
    telefone = '$telefone'
    whats = '$whats',
    nascimento = '$nascimento'
    where 
    codigo = '$id'
    ";

    $executar = mysqli_query($conn, $alterar);
    if($executar){
        echo "Dados alterados com sucesso";
    }else{
        echo "Erro ao alterar os dados";

    }
?>
<a href="../consulta/consulta-amigos.php">Voltar</a>