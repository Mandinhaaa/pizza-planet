<?php
    // CONSULTA USUÁRIO NO BANCO USANDO URL
    include_once "../../factory/conexao.php";
    if(isset($_GET["cxpesquisanome"])) {
        $nome = $_GET["cxpesquisanome"];
        $consultar = "SELECT * FROM tbusuario WHERE nome = '$nome'";
        $executar = mysqli_query($conn, $consultar);
        $linha = mysqli_fetch_array($executar);

        
    }
        
?>