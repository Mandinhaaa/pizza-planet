
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include_once "../../factory/conexao.php";
    $pesquisa = $_POST["cxpesquisaamigos"];
    $consulta = "select *from tbamigos where amigo = '$pesquisa' ";
    $executar = mysqli_query($conn, $consultar);
    $linha = mysqli_fetch_array($executar);
    ?>

    <form action="alterarproduto.php" method="POST">
    Código: <br>
    <input type="text" name="cxemail" value="<?php echo $linha["email"]?>" /></br>

    Produto: <br>
    <input type="text" name="cxamigos" value="<?php echo $linha["amigos"]?>" /></br>
    
    Marca: <br>
    <input type="text" name="cxwhats" value="<?php echo $linha["whats"]?>" /></br>
    <input type="submit" value="Alterar">
    </form>
</body>
</html>

<?php
    // CONSULTA USUÁRIO NO BANCO USANDO URL

    
    

    // include_once "../../factory/conexao.php";
    // if(isset($_GET["cxpesquisaamigos"])) {
    //     $amigo = $_GET["cxpesquisaamigos"];
    //     $consultar = "SELECT * FROM tbamigos WHERE amigo = '$amigo'";
    //     $executar = mysqli_query($conn, $consultar);
    //     $linha = mysqli_fetch_array($executar);
    // }
        
    // <?php
    // include_once "factory/conexao.php";
    // $pesquisa = $_POST["cxpesquisaproduto"];
    // $consulta = "select *from tbproduto where produto = '$pesquisa' ";
    // $executar = mysqli_query($conn, $consulta);
    // $linha = mysqli_fetch_array($executar);
    // ?>
