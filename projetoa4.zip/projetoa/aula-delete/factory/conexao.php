<?php 
    $server= "localhost";
    $user= "root";
    $senha= "";
    $banco= "bdauladelete";
    $conn= mysqli_connect(
        $server,$user,$senha,$banco
    )


?>
