<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
      rel="stylesheet"
    />
    <title>Alterar login</title>
</head>
<body>
    <header class="banner">
        <div class="menu-img">
            <img src="../../app/assets/img/pizza1.png" alt="" />
        </div>
        <nav>
            <ul>
                <li><a class="item-menu" href="../../index.php">Home</a></li>
                <li><a class="item-menu" href="../../app/estrutura/menu.php">Menu</a></li>
                <li><a class="item-menu" href="../../app/estrutura/login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <?php
                        include_once "../../factory/conexao.php";
                            $id = $_POST["cxcodigo"];
                            $nome = $_POST["cxnome"];
                            $email = $_POST["cxemail"];
                            $senha = $_POST["cxsenha"];

                            $alterar = "
                            UPDATE tblogin SET 
                            nome = '$nome',
                            email = '$email',
                            senha = '$senha'
                            where 
                            cod = '$id'";
                            ?>

    <section>
        <div class="container">
            <div class="center">
                <div class="formulario">
                    <form action="../consulta/consulta-login.php">
                    
                    <?php

                            $executar = mysqli_query($conn, $alterar);
                            if($executar){
                                echo "Dados alterados com sucesso";
                            }else{
                                echo "Erro ao alterar os dados";

                            }
                        ?>
                        <input class="button" type="submit" value="Voltar" />
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php include '../../app/estrutura/footer.php'; ?>

    
</body>
</html>
