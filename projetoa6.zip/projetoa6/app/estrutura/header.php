<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" />
    <title>header</title>
</head>
<body>
<header class="banner">
      <div class="menu-img">
        <img src="/app/assets/img/pizza1.png" alt="" />
      </div>

      <nav>
        <ul>
          <li><a class="item-menu" href="../..//index.php">Home</a></li>
          <li><a class="item-menu" href="/app/estrutura/menu.php">Menu</a></li>
          <li><a class="item-menu" href="/app/estrutura/login.php">Login</a></li>
        </ul>
      </nav>
    </header>
</body>
