<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta
      name="viewport"
      content=" classth=device- classth, initial-scale=1.0"
    />

    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" /> 
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    <title>Menu</title>
    <?php 
      SESSION_START();
      if((!isset($_SESSION["email"])==true) && (!isset($_SESSION["senha"])==true))
      {
              header("location:app/estrutura/login.php");
      }
      $logado = $_SESSION["email"];
    ?>
  </head>
  <body>

    <header class="banner">
      <div class="menu-img">
      <img src="/projetoa/app/assets/img/pizza1.png" alt="" />
          </div>

      <nav>
        <ul>
          <li><a class="item-menu" href="index.php">Home</a></li>
          <li><a class="item-sobre" href="app/estrutura/menu.php">Menu</a></li>
          <li><a class="item-menu" href="app/estrutura/login.php">Login</a></li>
        </ul>
      </nav>
    </header>


    <section class="apresentacao">
      <div class="slide-bg"></div>
    </section>


      <section>
        <div class="container">
          <div class="center">
            <div class="card">
              <div class="cxamigo">
                <a href="/projetoa/acoes/cadastro/cadastro-amigos.php">
                  <h3>Quer ser um amigo?</h3>
                </a>
                <a href="/projetoa/acoes/cadastro/cadastro-amigos.php">
                  <figure class="icon">
                    <img src="/projetoa/app/assets/img/ovni.png" alt="" />
                  </figure>
                </a>
              </div>
            </div>

            <div class="card">
              <div class="cxcomercio">
                <a href="/projetoa/acoes/cadastro/cadastro-comercio.php">
                  <h3>Quer ser nosso comerciante?</h3>
                </a>
                <a href="/projetoa/acoes/cadastro/cadastro-comercio.php">
                  <figure class="icon">
                    <img src="/projetoa/app/assets/img/ovni (2).png" alt="" />
                  </figure>
                </a>
              </div>
            </div>

            <div class="card">
              <div class="cxusuario">
                <a href="/projetoa/acoes/cadastro/cadastro-usuario.php">
                  <h3>Crie uma conta!</h3>
                </a>
                <a href="/projetoa/acoes/cadastro/cadastro-usuario.php">
                  <figure class="icon">
                    <img src="/projetoa/app/assets/img/ovni (1).png" alt="" />
                  </figure>
                </a>
              </div>
            </div>

            <div class="cxconsultaamigo">
              <div class="card">
                <div class="cxusuario"></div>
              </div>
            </div>
            <div class="cxconsultacomercio">
              <div class="card">
                <div class="cxusuario"></div>
              </div>
            </div>
            <div class="cxconsultauser">
              <div class="card">
                <div class="cxusuario"></div>
              </div>
            </div>
          </div>
      </section>

      <div class="center">
      <div class="login">
    <form action="app/estrutura/sair.php">
        <div class="info">
            <figure>
                <img src="/projetoa/app/assets/img/alien.png" alt=""/>
            </figure>
            <div class="logado">
                <?php echo $logado?>
            </div>
        </div>
        <input class="littlebutton" type="submit" value="Sair" />
    </form>
</div>
</div>

    <?php include 'app/estrutura/footer.php'; ?>


  </body>
</html>
