<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta
      name="viewport"
      content=" classth=device- classth, initial-scale=1.0"
    />
    <title>Home</title>
    <link rel="stylesheet" href="css/stylemenu.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    <?php 
    SESSION_START();
    if((!isset($_SESSION["login"])==true) && (!isset($_SESSION["senha"])==true))
    {
            header("location:login.php");
    }
    $logado = $_SESSION["login"];
    ?>
  </head>
  <body>
    <header class="banner">
      <div class="menu-img">
        <img src="img/pizza1.png" alt="" />
      </div>

      <nav>
        <ul>
          <li><a class="item-sobre" href="index.php">Home</a></li>
          <li><a class="item-menu" href="menu.php">Menu</a></li>
          <li><a class="item-menu" href="login.php">Login</a></li>
        </ul>
      </nav>
    </header>

    <section>
      <div class="container">
        <div class="center">
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/queijo.png" alt="" />
            </figure>
            <h3>Queijo</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/marguerita.png" alt="" />
            </figure>
            <h3>Marguerita</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/peperoni.png" alt="" />
            </figure>
            <h3>Peperoni</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/marinara.png" alt="" />
            </figure>
            <h3>Marinara</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/cogumelo.png" alt="" />
            </figure>
            <h3>Cogumelo</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/vegeriana.png" alt="" />
            </figure>
            <h3>Vegetariana</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img//mexicana.png" alt="" />
            </figure>
            <h3>Mexicana</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/frutosdomar.png" alt="" />
            </figure>
            <h3>Frutos do mar</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="img/hawai.png" alt="" />
            </figure>
            <h3>Havaiana</h3>
          </div>
        </div>
      </div>
    </section>
  </body>
</html>
