<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Deletar comércio</title>
</head>

    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
            <?php
            include_once "../../factory/conexao.php";
            $id= $_GET["id"];
            $excluir = "delete from tbcomercio where cod='$id'";
            $executar = mysqli_query($conn,$excluir);
            if($executar){
                echo "Comércio excluido com sucesso";
            } else {
                echo "Erro ao excluir comércio";
            }?>
          <form action="<?php echo $base_url; ?>acoes/cadastro/cadastro-comercio.php">
            <input class="button" type="submit" value="Voltar" />
            </form>
          </div>
        </div>
      </div>
    </section>
    <?php include '../../app/estrutura/footer.php'; ?>
          </body>
          </html>