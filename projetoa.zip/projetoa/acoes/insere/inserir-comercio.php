<?php include '../../app/estrutura/header.php'; ?>

    <section>
        <div class="container">
            <div class="center">
                <div class="formulario">
                    <?php
                    if (isset($_POST["cxnome"]) && $_POST["cxnome"] != "") {
                        include_once '../../factory/conexao.php';
                        $nome = $_POST["cxnome"];
                        $comercio = $_POST["cxcomercio"];
                        $telefone = $_POST["cxtelefone"];
                        $whats = $_POST["cxwhats"];
                        $sql = "INSERT INTO tbcomercio(nome, comercio, telefone, whats) VALUES('$nome', '$comercio', '$telefone', '$whats')";
                        $query = mysqli_query($conn, $sql);

                        if ($query) {
                            echo "Dados cadastrados com sucesso!";
                        } else {
                            echo "Erro ao cadastrar os dados: " . mysqli_error($conn);
                        }
                    } else {
                        echo "Dados não cadastrados!";
                    }
                    ?>
                    <form action="<?php echo $base_url; ?>acoes/consulta/consulta-comercio.php">
                        <input class="button" type="submit" value="Acessar cadastro" />
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>
</body>
</html>
