<?php include '../../app/estrutura/header.php'; ?>

    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
          <?php

            if($_POST["cxamigo"] != ""){
              include_once '../../factory/conexao.php';
              $amigo = $_POST["cxamigo"];
              $email = $_POST["cxemail"];
              $telefone = $_POST["cxtelefone"];
              $whats = $_POST["cxwhats"];
              $nascimento = $_POST["cxdatanasc"];
              $sql = "INSERT INTO tbamigos (amigo, email, telefone, whats, datanasc)
                          VALUES ('$amigo', '$email', '$telefone', '$whats', '$nascimento')";
              $query = mysqli_query($conn, $sql);
                echo "Dados cadastrados com sucesso!";
              }
              else
              {
                echo "Dados não cadastrados!";
              }
          ?>
            <form action="<?php echo $base_url; ?>acoes/consulta/consulta-amigos.php">
            <input class="button" type="submit" value="Acessar cadastro" />
            </form>
          </div>
        </div>
      </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>

    
</body>
</html>
