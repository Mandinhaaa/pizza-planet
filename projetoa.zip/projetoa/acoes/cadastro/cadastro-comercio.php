<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Cadastrar comércio</title>
</head>

    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
            <figure>
              <img src="<?php echo $base_url; ?>app/assets/img/radar.png" alt="" />
            </figure>
            <form action="<?php echo $base_url; ?>acoes/insere/inserir-comercio.php" method="POST">
              <input
                class="input"
                type="text"
                name="cxnome"
                placeholder="Digite seu nome"
                required
              />
              <input
                class="input"
                type="text"
                name="cxcomercio"
                placeholder="Digite o nome do comércio"
                required
              />
              <input
                class="input"
                type="text"
                name="cxtelefone"
                placeholder="Digite seu Telefone"
                required
              />
              <input
                class="input"
                type="text"
                name="cxwhats"
                placeholder="Digite seu WhastApp"
                required
              />
              <input class="button" type="submit" value="Gravar" />

            </form>
            Já cadastrado?
            <a href="<?php echo $base_url; ?>acoes/consulta/consulta-comercio.php">Consulte-o!</a>
          </div>
        </div>
      </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>


</body>
</html>