<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Cadastrar amigo</title>
</head>

    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
            <figure>
              <img src="<?php echo $base_url; ?>app/assets/img/ovni(3).png" alt="" />
            </figure>
            <form action="<?php echo $base_url; ?>acoes/insere/inserir-amigos.php" method="POST">
              <input
                class="input"
                type="text"
                name="cxamigo"
                placeholder="Digite seu nome"
                required
              />
              <input
                class="input"
                type="email"
                name="cxemail"
                placeholder="Digite seu e-mail"
                required
              />
              <input
                class="input"
                type="text"
                name="cxtelefone"
                placeholder="Digite seu Telefone"
                required
              />
              <input
                class="input"
                type="text"
                name="cxwhats"
                placeholder="Digite seu WhastApp"
                required
              />
              <input
                class="input"
                type="date"
                name="cxdatanasc"
                placeholder="Insira sua Data de nascimento"
                required
              />
              <input class="button" type="submit" value="Gravar" />

            </form>
            Já cadastrado?
            <a href="<?php echo $base_url; ?>acoes/consulta/consulta-amigos.php">Consulte-o!</a>
          </div>
        </div>
      </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>


</body>

</html>
