<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Consultar amigo</title>
</head>


    <?php include_once "../../factory/conexao.php";

      if (isset($_GET['amigo'])) {
          $amigo = $_GET['amigo'];

          // Recuperar os dados do amigo do banco de dados
          $consulta = "SELECT * FROM tbamigos WHERE amigo = '$amigo'";
          $resultado = mysqli_query($conn, $consulta);
      }
?>
    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
              <form action="<?php echo $base_url; ?>acoes/busca/busca-amigos.php" method="POST">
                <input class="input" type="text" name="cxpesquisaamigos" placeholder="Digite o nome cadastrado">
                <input class="button" type="submit" value="Buscar">
              </form>
            

          </div>
        </div>
      </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>
    
</body>
</html> 

