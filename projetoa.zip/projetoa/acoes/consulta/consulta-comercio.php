<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Consultar comércio</title>
</head>

     <?php include_once "../../factory/conexao.php";

      if (isset($_GET['nome'])) {
          $nome = $_GET['nome'];

          // Recuperar os dados do amigo do banco de dados
          $consulta = "SELECT * FROM tbcomercio WHERE nome = '$nome'";
          $resultado = mysqli_query($conn, $consulta);
      }
?> 


    <section>
      <div class="container">
        <div class="center">
          <div class="formulario">
                    <form action="<?php echo $base_url; ?>acoes/busca/busca-comercio.php" method="POST">
                        <input class="input" type="text" name="cxpesquisacomercio" placeholder="Digite o nome cadastrado">
                        <input class="button" type="submit" value="Buscar">
                    </form>
          </div>
        </div>
      </div>
    </section>

    <?php include '../../app/estrutura/footer.php'; ?>

</body>
</html>