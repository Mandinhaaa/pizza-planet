<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Buscar amigo</title>
</head>


    <section>
        <div class="container">
            <div class="center">
            <div class="formulario">
            <?php
                include_once "../../factory/conexao.php";

                if (isset($_POST["cxpesquisaamigos"])) {
                    $nome = $_POST["cxpesquisaamigos"];
                    $consultar = "SELECT * FROM tbamigos WHERE amigo = '$nome'";
                    $executar = mysqli_query($conn, $consultar);

                    if ($executar) {
                        $linha = mysqli_fetch_array($executar);
                        if ($linha) {
                ?>

                <form action="<?php echo $base_url; ?>acoes/alterar/alterar-amigos.php" method="POST">
                    <input type="hidden" name="cxcodigo" value="<?php echo $linha['cod'] ?>" />
                    <input class="input" type="text" name="cxamigo" value="<?php echo $linha['amigo'] ?>" />
                    <input class="input"  name="cxemail" value="<?php echo $linha['email'] ?>" />
                    <input class="input" type="text" name="cxtelefone" value="<?php echo $linha['telefone'] ?>" />
                    <input class="input" type="text" name="cxwhats" value="<?php echo $linha['whats'] ?>" />
                    <input class="input" type="date" name="cxdatanasc" value="<?php echo $linha['datanasc'] ?>" />
                    <input class="button" type="submit" value="Alterar" />
                    <p> Deseja excluir o cadastro de seu amigo?
                        <a href="<?php echo $base_url; ?>acoes/deletar/deletar-amigos.php?id=<?php echo $linha["cod"]?>">Excluir</a>
                    </p>
                    </form>
                    <?php
                            } else {
                                echo "Amigo não encontrado. Verifique o nome e tente novamente.</p>";
                            }
                        } else {
                            echo "Erro na consulta ao banco de dados: " . mysqli_error($conn) . "</p>";
                        }
                    }
                    ?>
                            <br>
                    <?php if (!isset($linha) || !$linha): ?>
                    <form action="/projetoa/acoes/busca/busca-amigos.php" method="POST">
                        <input class="input" type="text" name="cxpesquisaamigos" placeholder="Digite o nome do amigo" required />
                        <input class="button" type="submit" value="Pesquisar novamente" />
                    </form>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</section>

                   
    <?php include '../../app/estrutura/footer.php'; ?>


</body>
</html>


   
