<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="stylesheet" href="/projetoa/app/assets/css/style.css" /> 
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    <title>Buscar usuário</title>
</head>
<body>
    <header class="banner">
        <div class="menu-img">
            <img src="../../app/assets/img/pizza1.png" alt="" />
        </div>
        <nav>
            <ul>
                <li><a class="item-menu" href="/projetoa/index.php">Home</a></li>
                <li><a class="item-menu" href="/projetoa/app/estrutura/menu.php">Menu</a></li>
                <li><a class="item-menu" href="/projetoa/app/estrutura/login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <div class="container">
            <div class="center">
                <div class="formulario">
                    
                    <?php
                    include_once "../../factory/conexao.php";

                    if (isset($_POST["cxpesquisausuario"])) {
                        $nome = $_POST["cxpesquisausuario"];
                        $consultar = "SELECT * FROM tbusuario WHERE nome = '$nome'";
                        $executar = mysqli_query($conn, $consultar);

                        if ($executar) {
                            $linha = mysqli_fetch_array($executar);
                            if ($linha) {
                    ?>
                    <form action="/projetoa/acoes/alterar/alterar-usuario.php" method="POST">
                        <input type="hidden" name="cxcodigo" value="<?php echo $linha['cod'] ?>" />
                        <input class="input" type="text" name="cxnome" value="<?php echo $linha['nome'] ?>" />
                        <input class="input" name="cxemail" value="<?php echo $linha['email'] ?>" />
                        <input class="input" type="password" name="cxsenha" value="<?php echo $linha['senha'] ?>" />
                        <input class="button" type="submit" value="Alterar" />
                        <p> Deseja excluir o cadastro do seu login?
                            <a href="/projetoa/acoes/deletar/deletar-usuario.php?id=<?php echo $linha["cod"]?>">Excluir</a>
                        </p>
                    </form>

                    <?php
                            } else {
                                echo "Usuário não encontrado. Verifique o nome e tente novamente.</p>";
                            }
                        } else {
                            echo "Erro na consulta ao banco de dados: " . mysqli_error($conn) . "</p>";
                        }
                    }
                    ?>
<br>
                    <?php if (!isset($linha) || !$linha): ?>
                    <form action="/projetoa/acoes/busca/busca-usuario.php" method="POST">
                        <input class="input" type="text" name="cxpesquisausuario" placeholder="Digite o nome do usuário" required />
                        <input class="button" type="submit" value="Pesquisar novamente" />
                    </form>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </section>

    <footer>
        <figure>
            <img src="/projetoa/app/assets/img/alien-footer.png" alt="Alien footer" />
        </figure>
        <div class="padding"></div>
        <div class="rodape">
            <p>Feito por:</p>
            <p>Amanda Santana Araújo</p>
            <p>Turma A</p>
            <p>3º INFO</p>
        </div>
        <div class="padding"></div>
        <div class="rodape">
            <p>IFSP - GRU</p>
            <p>Profº Anselmo</p>
            <p>Laboratório de Desenvolvimento para Internet</p>
        </div>
    </footer>
</body>
</html>
