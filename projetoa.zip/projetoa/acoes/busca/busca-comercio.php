<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Buscar comércio</title>
</head>
    <section>
    <div class="container">
        <div class="center">
            <div class="formulario">
                <?php
                include_once "../../factory/conexao.php";
                
                if (isset($_POST["cxpesquisacomercio"])) {
                    $nome = $_POST["cxpesquisacomercio"];
                    $consultar = "SELECT * FROM tbcomercio WHERE nome = '$nome'";
                    $executar = mysqli_query($conn, $consultar);

                    if ($executar) {
                        $linha = mysqli_fetch_array($executar);
                        if ($linha) {
                            ?>
                            <form action="<?php echo $base_url; ?>acoes/alterar/alterar-comercio.php" method="POST">
                                <input type="hidden" name="cxcodigo" value="<?php echo $linha['cod'] ?>" />
                                <input class="input" type="text" name="cxnome" value="<?php echo $linha['nome'] ?>" />
                                <input class="input" name="cxcomercio" value="<?php echo $linha['comercio'] ?>" />
                                <input class="input" type="text" name="cxtelefone" value="<?php echo $linha['telefone'] ?>" />
                                <input class="input" type="text" name="cxwhats" value="<?php echo $linha['whats'] ?>" />
                                <input class="button" type="submit" value="Alterar" />
                                <p> Deseja excluir o cadastro do seu comércio?
                                    <a href="<?php echo $base_url; ?>acoes/deletar/deletar-comercio.php?id=<?php echo $linha['cod'] ?>">Excluir</a>
                                </p>
                            </form>

                            <?php
                            } else {
                                echo "Comércio não encontrado. Verifique o nome e tente novamente.</p>";
                            }
                        } else {
                            echo "Erro na consulta ao banco de dados: " . mysqli_error($conn) . "</p>";
                        }
                    }
                    ?>
                            <br>
                    <?php if (!isset($linha) || !$linha): ?>
                    <form action="/projetoa/acoes/busca/busca-comercio.php" method="POST">
                        <input class="input" type="text" name="cxpesquisacomercio" placeholder="Digite o nome do comércio" required />
                        <input class="button" type="submit" value="Pesquisar novamente" />
                    </form>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include '../../app/estrutura/footer.php'; ?>


    
</body>
</html>
