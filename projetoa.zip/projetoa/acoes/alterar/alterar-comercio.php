<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Alterar comércio</title>
</head>

    <?php
                        include_once "../../factory/conexao.php";
                            $id = $_POST["cxcodigo"];
                            $nome = $_POST["cxnome"];
                            $comercio = $_POST["cxcomercio"];
                            $telefone = $_POST["cxtelefone"];
                            $whatsapp = $_POST["cxwhats"];

                            $alterar = "
                            UPDATE tbcomercio SET 
                            nome = '$nome',
                            comercio = '$comercio',
                            telefone = '$telefone',
                            whats = '$whatsapp'
                            where 
                            cod = '$id'";
                            ?>

    <section>
        <div class="container">
            <div class="center">
                <div class="formulario">
                    <form action="<?php echo $base_url; ?>acoes/consulta/consulta-comercio.php">
                    
                    <?php

                            $executar = mysqli_query($conn, $alterar);
                            if($executar){
                                echo "Dados alterados com sucesso";
                            }else{
                                echo "Erro ao alterar os dados";

                            }
                        ?>
                        <br>
                        <input class="button" type="submit" value="Voltar" />
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php include '../../app/estrutura/footer.php'; ?>

    
</body>
</html>
