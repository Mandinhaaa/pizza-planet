<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/stylemenu.css?v=2" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />
    <title>Consulta usuário</title>
</head>
<body>
<header class="banner">
      <div class="menu-img">
        <img src="img/pizza1.png" alt="" />
      </div>
      <nav>
        <ul>
          <li><a class="item-menu" href="index.php">Home</a></li>
          <li><a class="item-menu" href="menu.php">Menu</a></li>
          <li><a class="item-menu" href="login.php">Login</a></li>
        </ul>
      </nav>
    </header>

    <?php include 'buscaUser.php'?>

    <section>
        <div class="container">
            <div class="center">
                <div class="formulario">
                    <form action="consultanomeuser.php">
                        <input class="input" type="text" name="cxpesquisanome" placeholder="Digite o nome cadastrado">
                        <input class="button" type="submit" value="Buscar">
                    </form>

                    <form>
                        <input class="input" type="text" name="cxnome"  value="<?= isset($linha['nome']) ? $linha['nome'] : ''; ?>"/>

                        <input  class="input" type="email" name="cxemail" value="<?= isset($linha['email']) ? $linha['email'] : ''; ?>"/>

                        <input class="input" type="password" name="cxsenha" value="<?= isset($linha['senha']) ? $linha['senha'] : ''; ?>"/>

                    </form>
                </div>
            </div>
        </div>
    </section>

    
</body>
</html> 

