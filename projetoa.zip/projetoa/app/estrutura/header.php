<?php
$base_url = '/projetoa/'; // Ajuste esse caminho conforme necessário
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo $base_url; ?>app/assets/css/style.css" />
    <?php 
      SESSION_START();
      if((!isset($_SESSION["email"])==true) && (!isset($_SESSION["senha"])==true))
      {
              header("location:login.php");
      }
      $logado = $_SESSION["email"];
    ?>
</head>
<body>
<header class="banner">
      <div class="menu-img">
        <img src="<?php echo $base_url; ?>app/assets/img/pizza1.png" alt="Imagem de uma pizza" />
      </div>

      <nav>
        <ul>
          <li><a class="item-menu" href="<?php echo $base_url; ?>index.php">Home</a></li>
          <li><a class="item-menu" href="<?php echo $base_url; ?>app/estrutura/menu.php">Menu</a></li>
          <li><a class="item-menu" href="<?php echo $base_url; ?>app/estrutura/login.php">Login</a></li>
        </ul>
      </nav>
    </header>
</body>
</html>

