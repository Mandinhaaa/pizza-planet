<?php include '../../app/estrutura/header.php'; ?>
<head>
    <title>Menu</title>
</head>
    <section>
      <div class="container">
        <div class="center">
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/queijo.png" alt="" />
            </figure>
            <h3>Queijo</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/marguerita.png" alt="" />
            </figure>
            <h3>Marguerita</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/peperoni.png" alt="" />
            </figure>
            <h3>Peperoni</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/marinara.png" alt="" />
            </figure>
            <h3>Marinara</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/cogumelo.png" alt="" />
            </figure>
            <h3>Cogumelo</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/vegeriana.png" alt="" />
            </figure>
            <h3>Vegetariana</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img//mexicana.png" alt="" />
            </figure>
            <h3>Mexicana</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/frutosdomar.png" alt="" />
            </figure>
            <h3>Frutos do mar</h3>
          </div>
          <div class="card-pizza">
            <figure class="pizza">
              <img src="../assets/img/hawai.png" alt="" />
            </figure>
            <h3>Havaiana</h3>
          </div>
        </div>
      </div>
    </section>



    <?php include '../estrutura/footer.php'; ?>


  </body>
</html>
