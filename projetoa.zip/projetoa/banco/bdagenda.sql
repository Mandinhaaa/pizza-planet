-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Ago-2024 às 04:22
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdagenda`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbamigos`
--

CREATE TABLE `tbamigos` (
  `cod` int(11) NOT NULL,
  `amigo` varchar(90) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `telefone` varchar(50) DEFAULT NULL,
  `whats` varchar(20) DEFAULT NULL,
  `datanasc` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tbamigos`
--

INSERT INTO `tbamigos` (`cod`, `amigo`, `email`, `telefone`, `whats`, `datanasc`) VALUES
(1, 'a', 'a', 'a', 'aa', '2006-12-12'),
(2, 'a', 'a', 'a', 'a', '1111-11-11'),
(3, 'g', 'g', 'g', 'g', '2024-08-30'),
(5, 'e', 'e@ee', 'e', 'e', '2024-08-30'),
(6, 'a', 'a@a', 'a', 'a', '2024-08-16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbcomercio`
--

CREATE TABLE `tbcomercio` (
  `cod` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `comercio` varchar(90) DEFAULT NULL,
  `telefone` varchar(50) DEFAULT NULL,
  `whats` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tbcomercio`
--

INSERT INTO `tbcomercio` (`cod`, `nome`, `comercio`, `telefone`, `whats`) VALUES
(1, 'a', 'a', 'a', 'a'),
(2, 'a', 'a', 'a', 'a'),
(3, 'a', 'a', 'a', 'a'),
(5, 'w', 'w', 'ww', 'ww');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbusuario`
--

CREATE TABLE `tbusuario` (
  `cod` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tbusuario`
--

INSERT INTO `tbusuario` (`cod`, `nome`, `email`, `senha`) VALUES
(1, 'a', 'a', 'a'),
(2, 't', 't', 't'),
(5, 'w', 'w', 'ww'),
(6, 'w', 'w', 'w'),
(7, 's', 's@s', 's');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tbamigos`
--
ALTER TABLE `tbamigos`
  ADD PRIMARY KEY (`cod`);

--
-- Índices para tabela `tbcomercio`
--
ALTER TABLE `tbcomercio`
  ADD PRIMARY KEY (`cod`);

--
-- Índices para tabela `tbusuario`
--
ALTER TABLE `tbusuario`
  ADD PRIMARY KEY (`cod`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbamigos`
--
ALTER TABLE `tbamigos`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `tbcomercio`
--
ALTER TABLE `tbcomercio`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `tbusuario`
--
ALTER TABLE `tbusuario`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
